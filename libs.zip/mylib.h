/*
	Como solicitado, foi gerado a biblioteca mylib.a contendo os arquivos com as funções run e pipeline de modo estático
	e também de modo dinâmico (mylib.so)


	Suas utilizações são simples:
	gcc main.c -o -L. -lmylib -o main (static library)

	e

	gcc main.c -o -L. -lmylib -o main (shared dynamic library)




*/
