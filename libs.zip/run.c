#include <stdio.h>			
#include <stdlib.h>			
#include <unistd.h>			
#include <sys/types.h>		
#include <sys/wait.h>		
#include "run.h"

char **command_args;


void set_command_args(char **end_cmd) {
	command_args = end_cmd;
}



int run(const char *command, int *result) {
	pid_t child_pid;
	int status;


	child_pid = fork();

	if(child_pid == 0) {
		execvp(command, command_args);
		perror("execvp");
		exit(EXIT_FAILURE);
	} else {

		wait(&status);

		if(WIFEXITED(status)){
			if(result != NULL) *result = WEXITSTATUS(status);
			printf("Valor de result = %d\n", *result);
			return child_pid;
		}
		else
			return -1;
	}

	return 0;

	}
