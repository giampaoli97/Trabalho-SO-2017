#include <stdio.h>
#include "pipeline.h"
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>


int pipeline(FILE *fpin, FILE *fpout, char ***cmd) {
	int p[2];
	pid_t pid;
	int fd_input = 0;


	


	while ((*cmd) != NULL) {
		pipe(p);
		if ((pid = fork()) == -1) {
			exit(EXIT_FAILURE);
		}
		else if (pid == 0) {    
			dup2(fd_input, 0);
			if (*(cmd + 1) != NULL) dup2(p[1], 1);
			close(p[0]);
			execvp((*cmd)[0], *cmd);
			exit(EXIT_FAILURE);
		}
		else {
			wait(NULL);
			close(p[1]);
			fd_input = p[0];
			cmd++;
		}
	}



	

	return 1;
}




