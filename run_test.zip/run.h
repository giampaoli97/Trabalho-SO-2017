#ifndef _RUN_H_
#define _RUN_H_

int run(const char *command, int *result);
void set_command_args(char **end_cmd);

#endif
