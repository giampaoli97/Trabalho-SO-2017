#include <stdio.h>
#include <stdlib.h>
#include "run.h"

int main(int argc, char *argv[]) {
	int result = 0;
	char *command;

	if(argc < 2) {
		printf("<program> <arg1> <arg2>...<argN>.\n");
		exit(0);
	}
	
	command = argv[1];

	set_command_args(&argv[1]);

	printf("Retorno da funcao run: %d\n", run(command, &result));

	return 0;
}
