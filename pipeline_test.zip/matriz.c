#include <stdlib.h>
#include <stdio.h>
#include "matriz.h"

char **cria_Matriz(int lin, int col) {
	int i;
	char **m = (char **) malloc(sizeof(char *) * lin);
	for(i = 0; i < lin; i++) m[i] = (char *) malloc(sizeof(char) * col);

	return m;
}

/*int **matriz_cpy(int **m, int lin, int col) {
	int **n = cria_Matriz(lin, col);
	int i, j;

	for(i = 0; i < lin; i++) {
		for(j = 0; j < col; j++) {
			n[i][j] = m[i][j];
		}
	}

	return n;
}

int **ler_Matriz(int num_vert, int num_arest) {
	int i, j;
	int **m = cria_Matriz(num_vert, num_arest);

	for(i = 0; i < num_vert; i++)
		for(j = 0; j < num_arest; j++)
			scanf("%d", &m[i][j]);

	return m;
}
*/
void libera_Matriz(char **m, int lin) {
	int i;
	for(i = 0; i < lin; i++) free(m[i]);
	free(m);
}
/*
void preenche_Matriz(int **n, int lin, int col, int val) {
	int i, j;

	for(i = 0; i < lin; i++)
		for(j = 0; j < col; j++)
			n[i][j] = val++;

	n[i-1][col-1] = 0;

}

void print_matriz(int **m, int lin, int col) {
	int i, j;

	for(i = 0; i < lin; i++) {
		for(j = 0; j < col; j++) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}

}

void print_matriz_I(int **m, int lin, int col) {
	int i, j;

	for(i = 0; i < lin; i++) {
		for(j = col-1; j >= 0; j--) {
			printf("%d ", m[i][j]);
		}
		printf("\n");
	}

}*/
