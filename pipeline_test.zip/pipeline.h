#ifndef _PIPELINE_H_
#define _PIPELINE_H_

int pipeline(FILE *, FILE *, char ***);


#endif
