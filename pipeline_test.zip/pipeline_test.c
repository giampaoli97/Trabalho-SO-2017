#include <stdlib.h>
#include <stdio.h>
#include "matriz.h"
#include "pipeline.h"
#include <string.h>

char *readLine(FILE *fp) {
	char *str = NULL;
	int counter = 0, c;

	do {
		c = fgetc(fp);
		str = (char *) realloc(str, sizeof(char) * (counter + 1));
		str[counter++] = c;
	} while(c != 10);
	str[counter-1] = '\0';


	return str;
}


char **read_command() {
	char **m = NULL;
	char *token, *cmd;
	int counter = 0;

	cmd = readLine(stdin);

	token = strtok(cmd, " ");

	while(token != NULL) {
		m = (char **) realloc(m, sizeof(char *) * (counter + 1));
		m[counter++] = token;
		token = strtok(NULL, " ");
	}

	m = (char **) realloc(m, sizeof(char *) * (counter + 1));
	m[counter++] = NULL;


	return m;
}


int main(int argc, char *argv[]) {
	int i, counter_commands = 0;
	char ***commands = NULL, **cmd;
	FILE *fpin, *fpout;
	int pipe_result;

	fpin = fopen("fpin.in", "w+");
	fpout = fopen("fpout.out", "w+");

	printf("[Comando %d]$ ", counter_commands+1);
	cmd = read_command();
	
	
	while(strcmp(cmd[0], "NULL") != 0) {
		fprintf(fpin, "%s\n", cmd[0]);
		commands = (char ***) realloc(commands, sizeof(char **) * (counter_commands+1));
		commands[counter_commands++] = cmd;
		printf("[Comando %d]$ ", counter_commands+1);
		cmd = read_command();
	}
	commands = (char ***) realloc(commands, sizeof(char **) * (counter_commands+1));
	commands[counter_commands++] = NULL;


	pipe_result = pipeline(fpin, fpout, commands);


	for(i = 0; i < counter_commands; i++) {
		libera_Matriz(commands[i], 0);
	}



	fclose(fpin);
	fprintf(fpout, "Saida funcao pipeline :%d\n", pipe_result);
	fclose(fpout);

	return 0;
}






