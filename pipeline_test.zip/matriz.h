#ifndef _MATRIZ_H_
#define _MATRIZ_H_

int **ler_Matriz(int num_vert, int num_arest);
void print_matriz(int **m, int lin, int col);
void libera_Matriz(char **m, int num_arest);
char **cria_Matriz(int lin, int col);
void preenche_Matriz(int **n, int lin, int col, int val);
void print_matriz_I(int **m, int lin, int col);
int **matriz_cpy(int **m, int lin, int col);




#endif
